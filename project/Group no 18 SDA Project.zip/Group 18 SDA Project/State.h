/**
 * Project Untitled
 */
#pragma once
#include<iostream>
#include <unordered_map>
using namespace std;
enum class State {
    New,
    Assigned,
    Resolved,
    Closed
};

