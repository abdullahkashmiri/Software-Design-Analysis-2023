/**
 * Project Untitled
 */

#include <iostream>
#include "State.h"
#include <string>
using namespace std;

#ifndef _COMPLAINT_H
#define _COMPLAINT_H

class Complaint {
private:
    int id;
    int feedback_given;
    string description;
    string dept;
    int teacher_id;
    State status;
public:
    Complaint();

    Complaint(int ID, string desc, string dept, int t_id, State stat, int emp_id);

    State CurrentState() const;

    int getId() const;

    int getComplaintEmployeeId() const;

    string getComplaintDesc() const;

    void setCurrentState(State newStatus);

    string getComplaintDept() const;

    int getComplaintTeacherId()  const;

    int getFeedback();

    int getFeedback() const;

    void ChangeState(State newStatus);

    void PrintDetails() const;

    void setFeedbackGiven(int fg);

    void PrintDetails(int teacherID) const;

    void PrintDetail() const;

    string  feedbackPrint(int f) const;

    string stateToString(State status) const;
};

#endif //_COMPLAINT_H