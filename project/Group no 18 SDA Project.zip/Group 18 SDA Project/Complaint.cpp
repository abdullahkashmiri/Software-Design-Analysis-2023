/**
 * Project Untitled
 */


#include "Complaint.h"

 /**
  * Complaint implementation
  */

  // Default constructor
Complaint::Complaint() {
    id = 0;
    description = "";
    dept = "";
    teacher_id = 0;
    status = State::New;
    feedback_given = -1;
}

// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};

// Overloaded constructor
Complaint::Complaint(int ID, string desc, string dept, int t_id, State stat, int emp_id) {
    id = ID;
    description = desc;
    this->dept = dept;
    teacher_id = t_id;
    status = stat;
    feedback_given = emp_id;
}

State Complaint::CurrentState() const {
    return status;
}

int Complaint::getId() const
{
    return id;
}

int Complaint::getComplaintEmployeeId() const
{
    return feedback_given;
}

string Complaint::getComplaintDesc() const
{
    return description;
}

void Complaint::setCurrentState(State newStatus)
{
    status = newStatus;
}

string Complaint::getComplaintDept() const
{
    return dept;
}

int Complaint::getComplaintTeacherId() const
{
    return teacher_id;
}

int Complaint::getFeedback()
{
    return feedback_given;
}

int Complaint::getFeedback() const
{
    return feedback_given;

}

void Complaint::ChangeState(State newStatus) {
    status = newStatus;
}

void Complaint::PrintDetails() const {
    cout << "Complaint ID: " << id << ", Description: " << description
        << ", Department: " << dept << ", Teacher ID: " << teacher_id
        << ", Status: " << stateToString(status) << endl;
    cout << "-------------------------------------------------------" << endl;
}

void Complaint::setFeedbackGiven(int fg)
{
    feedback_given = fg;
}

void Complaint::PrintDetails(int teacherID) const
{
    if (teacherID == teacher_id) {
        cout << "Complaint ID: " << id << ", Description: " << description
            << ", Department: " << dept << ", Teacher ID: " << teacher_id
            << ", Status: " << stateToString(status) << endl;
    }
}

void Complaint::PrintDetail() const
{
        cout << "Complaint ID: " << id << ", Description: " << description
            << ", Department: " << dept << ", Teacher ID: " << teacher_id
            << ", Status: " << stateToString(status) << "Feedback : "<< feedbackPrint(feedback_given) << endl;
}
 
string Complaint::feedbackPrint(int f) const
{
    if (f == -1) {
        return "No Feedback Given / Complaint in Progress";
    }
    else if (f == 0) {
        return "Satisfied";
    }
    else if (f == 1) {
        return "DisSatisfied";
    }
    else {
        return "No record found";
    }
}

string Complaint::stateToString(State state) const
{
    static const std::unordered_map<State, std::string> stateStrings = {
       {State::New, "New"},
       {State::Assigned, "Assigned"},
       {State::Resolved, "Resolved"},
       {State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
}