/**
 * Project Untitled
 */


#include "AssignedJob.h"

 /**
  * Assigned Job implementation
  */

AssignedJob::AssignedJob()
{
	assignDate = "";
}

AssignedJob::AssignedJob(string date, int cid, int tid, vector<int> e_ids, State stat)
{
    assignDate = date;
    complaintID = cid;
    teacherID = tid;
    employeeIDs = e_ids;
    status = stat;
}

void AssignedJob::readAssignedJobFromString(string line) {
    
    istringstream iss(line);
     // Implement the logic to read data from the istringstream and set the member variables
    iss >> assignDate >> complaintID >> teacherID;
     
    int employeeID;
    iss >> employeeID;
    while (iss >> employeeID) {
        if (employeeID == -1) {
            break;
        }
        employeeIDs.push_back(employeeID);
    }
    string stat;
    iss >> stat;
    status = stringToState(stat);
}

bool AssignedJob::matchEmployeeId(istringstream& iss, int eid)
{

    string assignDat;
    int complaintI;
    int teacherI;
    string statu;
    // Implement the logic to read data from the istringstream and set the member variables
    iss >> assignDat >> complaintI >> teacherI;

     
    int employee;
    iss >> employee;
    while (iss >> employee) {
        if (employee == -1) {
            break;
        }
     
        if (eid == employee) {
            return true;
        }
      
    }

    string stat;
    iss >> stat;
    status = stringToState(stat);   
    return false;
}

void AssignedJob::setComplaintID(int id) {
    complaintID = id;
}

int AssignedJob::getComplaintID() const {
    return complaintID;
}

void AssignedJob::setTeacherID(int id) {
    teacherID = id;
}

int AssignedJob::getTeacherID() const {
    return teacherID;
}

void AssignedJob::setEmployeeIDs(const vector<int>& ids) {
    employeeIDs = ids;
}

const vector<int>& AssignedJob::getEmployeeIDs() const {
    return employeeIDs;
}

void AssignedJob::setDate(string d) {
    assignDate = d;
}

string AssignedJob::getDate() const {
    return assignDate;
}

void AssignedJob::setStatus(State s) {
    status = s;
}

State AssignedJob::getStatus() const {
    return status;
}

void AssignedJob::writeAssignedJobToFile(ofstream& file) const {
    int a = -1;
    file << assignDate << " " << complaintID << " " << teacherID << " "<< a<< " ";
    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        file << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            file << " ";
        }
    }
    file << " " << a << " " << stateToString(status) << "\n";

}

string AssignedJob::printDetails(int eid) const {
    // Check if the provided employee ID matches any of the employee IDs in the AssignedJob
    auto it = find(employeeIDs.begin(), employeeIDs.end(), eid);
    if (it == employeeIDs.end()) {
        return "";  // Return an empty string if no match is found
    }

    ostringstream details;
    details << "Assign Date: " << assignDate << " "
        << "Complaint ID: " << complaintID << " "
        << "Teacher ID: " << teacherID << " "
        << "Employee IDs: [";

    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        details << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            details << ", ";
        }
    }
    details << "] "
        << "Status: " << stateToString(status) << "\n";

    return details.str();
}

string AssignedJob::printDetails() const
{

    ostringstream details;
    details << "Assign Date: " << assignDate << " "
        << "Complaint ID: " << complaintID << " "
        << "Teacher ID: " << teacherID << " "
        << "Employee IDs: [";

    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        details << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            details << ", ";
        }
    }
    details << "] "
        << "Status: " << stateToString(status) << "\n";

    return details.str();
}
 
void AssignedJob::printAssignDetails(int eid) const {
    // Check if the provided employee ID matches any of the employee IDs in the AssignedJob
    auto it = find(employeeIDs.begin(), employeeIDs.end(), eid);
    if (it == employeeIDs.end()) {
        return ;  // Return an empty string if no match is found
    }

    ostringstream details;
    details << "Assign Date: " << assignDate << " "
        << "Complaint ID: " << complaintID << " "
        << "Teacher ID: " << teacherID << " "
        << "Employee IDs: [";

    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        details << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            details << ", ";
        }
    }
    details << "] "
        << "Status: " << stateToString(status) << "\n";
    if (status == State::Assigned)
        cout<< details.str();
    else
        return ;
}

void AssignedJob::printAssignDetails( ) const {
   
    ostringstream details;
    details << "Assign Date: " << assignDate << " "
        << "Complaint ID: " << complaintID << " "
        << "Teacher ID: " << teacherID << " "
        << "Employee IDs: [";

    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        details << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            details << ", ";
        }
    }
    details << "] "
        << "Status: " << stateToString(status) << "\n";
    if (status == State::Assigned)
        cout << details.str();
    else
        return;
}

void AssignedJob::printResolvedDetails() const {
   
    ostringstream details;
    details << "Assign Date: " << assignDate << " "
        << "Complaint ID: " << complaintID << " "
        << "Teacher ID: " << teacherID << " "
        << "Employee IDs: [";

    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        details << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            details << ", ";
        }
    }
    details << "] "
        << "Status: " << stateToString(status) << " ";
    
    if (status == State::Resolved)
        cout << details.str();
}

bool AssignedJob::printResolvedDetails()
{
    ostringstream details;
    details << "Assign Date: " << assignDate << " "
        << "Complaint ID: " << complaintID << " "
        << "Teacher ID: " << teacherID << " "
        << "Employee IDs: [";

    for (size_t i = 0; i < employeeIDs.size(); ++i) {
        details << employeeIDs[i];
        if (i < employeeIDs.size() - 1) {
            details << ", ";
        }
    }
    details << "] "
        << "Status: " << stateToString(status) << " ";

    if (status == State::Resolved)
    {
        cout << details.str();
        return true;
    }
    return false;
}
// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};

string AssignedJob::stateToString(State state) const
{
    static const std::unordered_map<State, std::string> stateStrings = {
   {State::New, "New"},
   {State::Assigned, "Assigned"},
   {State::Resolved, "Resolved"},
   {State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
}

State AssignedJob::stringToState(string str)
{
    static const std::unordered_map<std::string, State> stateMap = {
       {"New", State::New},
       {"Assigned", State::Assigned},
       {"Resolved", State::Resolved},
       {"Closed", State::Closed}
    };

    auto it = stateMap.find(str);
    if (it != stateMap.end()) {
        return it->second;
    }
    else {
        return State::New;  // Default value for unknown strings
    }
}