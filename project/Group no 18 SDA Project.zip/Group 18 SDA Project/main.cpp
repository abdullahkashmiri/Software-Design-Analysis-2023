#include <iostream>
#include "Person.h"
#include "Administer.h"
#include "Director.h"
#include "Teacher.h"
#include "Employee.h"
#include "Manager.h"
#include <windows.h>

using namespace std;

template<typename Temp>
void LoadDataFromFiles(string file, vector<Temp>& _vector) {

	ifstream inputFile(file);
	if (!inputFile.is_open()) {
		cerr << "Error: Unable to open file: " << file << endl;
		return;
	}

	string line;
	while (getline(inputFile, line)) {
		stringstream ss(line);
		int id;
		string name;

		// Assuming the data is formatted as "ID Name"
		if (ss >> id >> name) {
			Temp temp{ id, name };
			_vector.push_back(temp);
		}
		else {
			cerr << "Error: Invalid data format in file: " << file << endl;
		}
	}

	inputFile.close();
}
 
template<typename Temp>
void LoadDataFromFileEmployee(string file, vector<Temp>& _vector) {

	ifstream inputFile(file);
	if (!inputFile.is_open()) {
		cerr << "Error: Unable to open file: " << file << endl;
		return;
	}

	string line;
	while (getline(inputFile, line)) {
		stringstream ss(line);
		int id;
		string name, dept;

		// Assuming the data is formatted as "ID Name"
		if (ss >> id >> name >> dept) {
			Temp temp{ id, name , dept};
			_vector.push_back(temp);
		}
		else {
			cerr << "Error: Invalid data format in file: " << file << endl;
		}
	}

	inputFile.close();
}

void updateAllDepartments(vector<Department>* _departments) {
	
	ofstream file("departments.txt");

	if (file.is_open()) {
		for (const Department& department : *_departments) {
				file << department.getId() << " "
					<< department.getName() << " "
					<< department.getTotalComplaints() << endl;
		}
		file.close();
	}
	else {
		cout << "Unable to open file 'departments.txt' for writing." << endl;
	}
}

Person* Login() {

	Person* _person = NULL;
	int _input = 0;
	bool _endProgram = false;
	int _id = 0;
	string _name = "";

	Administer *_administer = new Administer;
	Director* _director = new Director;
	Teacher* _teacher = new Teacher;
	Manager* _manager = new Manager;
	Employee* _employee = new Employee;

	//-----------

	vector<Employee>* _employees;
	vector<Manager>* _managers;
	vector<Teacher>* _teachers;
	vector<Administer>* _administers;
	vector<Director>* _directors;
	vector<Department>* _departments;

	_employees = new vector<Employee>();
	_managers = new vector<Manager>();
	_teachers = new vector<Teacher>();
	_administers = new vector<Administer>();
	_directors = new vector<Director>();
	_departments = new vector<Department>();

	LoadDataFromFileEmployee<Employee>("employees.txt", *_employees);
	LoadDataFromFileEmployee<Manager>("managers.txt", *_managers);
	LoadDataFromFiles<Teacher>("teachers.txt", *_teachers);
	LoadDataFromFiles<Administer>("administers.txt", *_administers);
	LoadDataFromFiles<Director>("directors.txt", *_directors);
	LoadDataFromFiles<Department>("departments.txt", *_departments);
	updateAllDepartments(_departments);
	//-----------

	

	while (_endProgram == false) {
		cout << "<<-- LOGIN PANEL -->>" << endl;
		if (_administer != NULL) {
			cout << "[1] ->> Administer" << endl;
		}
		if (_director != NULL) {
			cout << "[2] ->> Director" << endl;
		}
		if(_teacher != NULL){
			cout << "[3] ->> Teacher" << endl;
		}
		if (_manager != NULL) {
			cout << "[4] ->> Manager" << endl;
		}
		if (_employee != NULL) {
			cout << "[5] ->> Employee" << endl;
		}
		cout << "[0] ->> Exit" << endl;
		cout << "Enter Here >> ";
		cin >> _input;
		if (_input == 0) {
			_endProgram = true;
		} else if (_input == 1) {
			cout << "Administer Selected" << endl;
			cout << "Enter the ID of Administer: ";
			cin >> _id;

			bool validID = false;

			for (const auto& admin : *_administers) {
				if (_id == admin.getId()) {
					validID = true;
					_name = admin.getName();
					break;
				}
			}

			while (!validID) {
				cout << "Invalid Administer Id" << endl;
				cout << "Enter Again: ";
				cin >> _id;

				for (const auto& admin : *_administers) {
					if (_id == admin.getId()) {
						validID = true;
						_name = admin.getName();
						break;
					}
				}
			}

			cout << "Welcome Administer!" << endl;
			_administer->setID(_id);
			_administer->setName(_name);
			_person = _administer;
			_endProgram = true;
		} else if (_input == 2) {
			cout << "Director Selected" << endl;
			cout << "Enter the ID of Director: ";
			cin >> _id;

			bool validID = false;

			for (const auto& director : *_directors) {
				if (_id == director.getId()) {
					validID = true;
					_name = director.getName();
					break;
				}
			}

			while (!validID) {
				cout << "Invalid Director Id" << endl;
				cout << "Enter Again: ";
				cin >> _id;

				for (const auto& director : *_directors) {
					if (_id == director.getId()) {
						validID = true;
						_name = director.getName();
						break;
					}
				}
			}

			cout << "Welcome Director!" << endl;
			_director->setID(_id);
			_director->setName(_name);
			_person = _director;
			_endProgram = true;
		} else if (_input == 3) {
			cout << "Teacher Selected" << endl;
			cout << "Enter the ID of Teacher: ";
			cin >> _id;

			bool validID = false;

			for (const auto& teacher : *_teachers) {
				if (_id == teacher.getId()) {
					validID = true;
					_name = teacher.getName();
					break;
				}
			}

			while (!validID) {
				cout << "Invalid Teacher Id" << endl;
				cout << "Enter Again: ";
				cin >> _id;

				for (const auto& teacher : *_teachers) {
					if (_id == teacher.getId()) {
						validID = true;
						_name = teacher.getName();
						break;
					}
				}
			}

			cout << "Welcome Teacher!" << endl;
			_teacher->setID(_id);
			_teacher->setName(_name);
			_person = _teacher;
			_endProgram = true;
		} else if (_input == 4) {
			cout << "Manager Selected" << endl;
			cout << "Enter the ID of Manager: ";
			cin >> _id;

			bool validID = false;
			string dept;

			for (const auto& manag : *_managers) {
				if (_id == manag.getId()) {
					validID = true;
					_name = manag.getName();
					dept = manag.getDepartment();
					break;
				}
			}


			while (!validID) {
				cout << "Invalid Manager Id" << endl;
				cout << "Enter Again: ";
				cin >> _id;

				for (const auto& manag : *_managers) {
					if (_id == manag.getId()) {
						validID = true;
						_name = manag.getName();
						dept = manag.getDepartment();
						break;
					}
				}
			}

			cout << "Welcome Manager!" << endl;
			_manager->setID(_id);
			_manager->setName(_name);
			_manager->setdept(dept);
		
			_manager = new Manager(_id, _name, dept);
			_person = _manager;
			_endProgram = true;

		} else if (_input == 5) {
			cout << "Employee Selected" << endl;
			cout << "Enter the ID of Employee: ";
			cin >> _id;

			bool validID = false;
			string dept;

			for (const auto& employ : *_employees) {
				if (_id == employ.getId()) {
					validID = true;
					_name = employ.getName();
					dept = employ.getDepartment();
					break;
				}
			}

			while (!validID) {
				cout << "Invalid Employee Id" << endl;
				cout << "Enter Again: ";
				cin >> _id;

				for (const auto& employ : *_employees) {
					if (_id == employ.getId()) {
						validID = true;
						_name = employ.getName();
						dept = employ.getDepartment();

						break;
					}
				}
			}

			cout << "Welcome Employee!" << endl;
			_employee->setID(_id);
			_employee->setName(_name);
			_employee = new Employee(_id, _name, dept);
			_person = _employee;
			_endProgram = true;
			} else {
			cout << "Invalid Entry Try Again!!." << endl;
			system("cls");
		}
	//	system("cls");
	}

	// Delete the dynamically allocated vectors
	delete _employees;
	delete _managers;
	delete _teachers;
	delete _administers;

	// Set pointers to nullptr to avoid potential issues
	_employees = nullptr;
	_managers = nullptr;
	_teachers = nullptr;
	_administers = nullptr;

	return _person;
}

int main() {


	while (true) {
		Person* _currentUser = Login();
		if (_currentUser == NULL) {
			break;
		}
		else {
			_currentUser->command();
			cout << "Execution Completed" << endl;
			system("cls");
		}
	}

	cout << "Program Terminated SuccessFully" << endl;
	return 0;
}
 