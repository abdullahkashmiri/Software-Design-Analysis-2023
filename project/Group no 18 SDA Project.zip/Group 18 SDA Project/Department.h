/**
 * Project Untitled
 */

#include <string>
#include "Complaint.h"
#include "Employee.h"
#include "AssignedJob.h"
#include <iostream>
#include <Windows.h>
#include <fstream>
#include <functional>
#include <sstream>
#include <vector>
#include <algorithm>
#include <cctype>

using namespace std;

#ifndef _DEPARTMENT_H
#define _DEPARTMENT_H

class Department {
    int id;
    string name;
    int totalComplains;
    vector<Employee>* _employee;
    vector<Complaint>* _complaint;
    vector<AssignedJob>* assignedJob;

public:

    Department();

    Department(int ID, string Name);

    int getId();

    int getId()const;

    string getName() const;

    string getName() ;

    int getTotalComplaints();

    int getTotalComplaints()const;

    vector<Complaint>* getData();
     
    void LoadDataFromFileEmploye(string file, vector<Employee>* _vector);

    void LoadAllComplaints();

    vector<Complaint>* GetLoadedAllComplaints();

    void writeComplaintsToFile(const std::string& filePath, int cid);

    void writeComplaintsToFileResolved(const std::string& filePath, int cid);

    void writeComplaintsToFileClosed(const std::string& filePath, int cid);

    bool isEmployeeIDValid(int employeeID) const;

    string EmployeeIDdept(int employeeID) const;

    void printAllEmployees(string dept);

    bool isComplaintIDValid(int complaintID) const;
     
    string getFormattedLine(int id);

    void setFeedback(int cid);

    bool isFeedbackGivenByComplaintId(int c);

    void updateComplaintStatus(int complaintID, const State& newStatus);

    State getComplaintStatusByID(int complaintID) const;

    int getComplaintTeacherIdByID(int complaintID) const;

    const Complaint& getComplaintByID(int complaintID) const;

    bool printComplaintByID(int complaintID);

    void readAssignedJobsFromFile();

    void printAllComplaints() const;

    void printNewComplaints() const;

    void UpdateComplaintStatusAfterFeedback();

    vector<int> printAccoringToMonth(int smon, int sye, int sda, int emon, int eye, int eda);

    State stringToState(string str);

    string stateToString(State state) const;

    string stateToString(State state);
};

#endif //_DEPARTMENT_H
 