/**
 * Project Untitled
 */


#include "Director.h"

 /**
  * Director implementation
  */


Director::Director()
{
    id = -1;
    name = "";
    _adminDepartment = new Department(1, "Admin");
    _itDepartment = new Department(2, "IT");
    _accountsDepartment = new Department(3, "Accounts");

}

Director::Director(int Id, string Name)
{
    id = Id;
    name = Name;
    _adminDepartment = new Department(1, "Admin");
    _itDepartment = new Department(2, "IT");
    _accountsDepartment = new Department(3, "Accounts");

}

int Director::getId() const
{
    return id;
}

string Director::getName() const
{
    return name;
}

void Director::setID(int ID)
{
    id = ID;
}

void Director::setName(string Name)
{
    name = Name;
}

void Director::command() {
    int choice;

    do {
        system("cls");

        cout << "Director " << name << endl;
        cout << "Command Function" << endl;
        cout << "1. View summary of complaints by department" << endl;
        cout << "2. View summary of complaints in a given TimeLine" << endl;
        cout << "3. View overall complaints summary" << endl;
        cout << "4. View details of a specific complaint" << endl;
        cout << "0. Exit" << endl;

        cout << "Enter your choice: ";
        cin >> choice;

        // Handle non-integer input
        while (cin.fail()) {
            cout << "Invalid input. Please enter a number." << endl;
            cin.clear();  // Clear the error flag
            cout << "Enter your choice: ";
            cin >> choice;
        }

        switch (choice) {
        case 1:
            Complains_in_Depts();
            break;
        case 2:
            printAllComplaintsInTimeLine();
            break;
        case 3:
            ComplainsSummary();
            break;
        case 4:
            ComplainDetails();
            break;
        case 0:
            cout << "Exiting Director Command Function." << endl;
            break;
        default:
            cout << "Invalid choice. Please enter a valid option." << endl;
        }

    } while (choice != 0);
}
  
void Director::pressAnyKeyToContinue()
{
    cout << "Press any key to continue...";

#ifdef _WIN32
    _getch(); // Use _getch() on Windows
#else
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
#endif

    cout << endl;
}

void Director::Complains_in_Depts() {
    int choice;
    cout << "Select department to view complaints:" << endl;
    cout << "1. Admin" << endl;
    cout << "2. IT" << endl;
    cout << "3. Accounts" << endl;
    cout << "Enter your choice: ";
    cin >> choice;

    switch (choice) {
    case 1:
        _adminDepartment->printAllComplaints();
        break;
    case 2:
        _itDepartment->printAllComplaints();
        break;
    case 3:
        _accountsDepartment->printAllComplaints();
        break;
    default:
        cout << "Invalid choice. Please enter a number between 1 and 3." << endl;
    }
    pressAnyKeyToContinue();

}

void Director::printAllComplaintsInTimeLine()
{
    cout << "----------------------------------------------------" << endl;
    cout << "----------------------------------------------------" << endl;
    cout << "Summary of Complaints Coordinated By Departments in Period of Time" << endl;
    int sdy, smn, syr;
    int edy, emn, eyr;

    // Get the year from the user with validation
    cout << "Enter Starting Date" << endl;
    do {
        cout << "Enter the Year (between 1900 and current year): ";
        cin >> syr;

        // Validate the input
        if (cin.fail() || syr < 1900 || syr > 2023) {
            cin.clear(); // Clear the error flag
            cout << "Invalid input. Please enter a valid year." << endl;
        }
        else {
            break; // Valid input, exit the loop
        }
    } while (true);

    // Get the month from the user
    cout << "Enter the Month (1-12): ";
    cin >> smn;

    // Validate the input
    if (cin.fail() || smn < 1 || smn > 12) {
        cout << "Invalid input. Please enter a valid month." << endl;
        pressAnyKeyToContinue();
        return;
    }
    // Get the month from the user
    cout << "Enter the Day (1-31): ";
    cin >> sdy;

    // Validate the input
    if (cin.fail() || sdy < 1 || sdy > 31) {
        cout << "Invalid input. Please enter a valid day." << endl;
        pressAnyKeyToContinue();
        return;
    }

    //--
    cout << "Enter Ending Date" << endl;
    do {
        cout << "Enter the Year (between 1900 and current year): ";
        cin >> eyr;

        // Validate the input
        if (cin.fail() || eyr < 1900 || eyr > 2023) {
            cin.clear(); // Clear the error flag
            cout << "Invalid input. Please enter a valid year." << endl;
        }
        else {
            break; // Valid input, exit the loop
        }
    } while (true);

    // Get the month from the user
    cout << "Enter the Month (1-12): ";
    cin >> emn;

    // Validate the input
    if (cin.fail() || emn < 1 || emn > 12) {
        cout << "Invalid input. Please enter a valid month." << endl;
        pressAnyKeyToContinue();
        return;
    }
    // Get the month from the user
    cout << "Enter the Day (1-31): ";
    cin >> edy;

    // Validate the input
    if (cin.fail() || edy < 1 || edy > 31) {
        cout << "Invalid input. Please enter a valid day." << endl;
        pressAnyKeyToContinue();
        return;
    }

    // Obtain complaint IDs for the specified month and year
    vector<int> complaintIDs;

    complaintIDs = _adminDepartment->printAccoringToMonth(smn, syr, sdy, emn, eyr, edy);
    if (complaintIDs.empty())
        complaintIDs = _itDepartment->printAccoringToMonth(smn, syr, sdy, emn, eyr, edy);
    if (complaintIDs.empty())
        complaintIDs = _accountsDepartment->printAccoringToMonth(smn, syr, sdy, emn, eyr, edy);

    // Display details for each complaint ID
    for (int complaintID : complaintIDs) {
        ComplainDetails(complaintID);
        cout << endl;
    }
    cout << "----------------------------------------------------" << endl;
    cout << "----------------------------------------------------" << endl;
    pressAnyKeyToContinue();

}

void Director::ComplainsSummary() {
    cout << "----------------------------------------------------------------------" << endl;
    cout << "-------------- Total Complaints in All Departments -------------------" << endl;
    cout << "----------------------------------------------------------------------" << endl;
    cout << "   Admin Department : " << _adminDepartment->getTotalComplaints()<<endl;
    cout << "   IT Department : " << _itDepartment->getTotalComplaints() << endl;
    cout << "   Accounts Department : " << _accountsDepartment->getTotalComplaints() << endl;
    cout << "----------------------------------------------------------------------" << endl;
    cout << "----------------------------------------------------------------------" << endl;
    cout << "----------------------------------------------------------------------" << endl;
    pressAnyKeyToContinue();
}

void Director::ComplainDetails() {
    int choice;
    cout << "Enter the Specfic Complaint Id that you want to see : " << endl;
    cin >> choice;

    if (_adminDepartment->printComplaintByID(choice)) {
        cout << "Complaint is in ADMIN DEPARTMENT" << endl;
    }
    else if (_itDepartment->printComplaintByID(choice)) {
        cout << "Complaint is in IT DEPARTMENT" << endl;
    }
    else if (_accountsDepartment->printComplaintByID(choice))
    {
        cout << "Complaint is in ACCOUNTS DEPARTMENT" << endl;
    }
    else {
        cout << "This Complaint Doesnot exist" << endl;
    }
  
    pressAnyKeyToContinue();
}

void Director::ComplainDetails(int choice) {

    if (_adminDepartment->printComplaintByID(choice)) {
        cout << "Complaint is in ADMIN DEPARTMENT" << endl;
    }
    else if (_itDepartment->printComplaintByID(choice)) {
        cout << "Complaint is in IT DEPARTMENT" << endl;
    }
    else if (_accountsDepartment->printComplaintByID(choice))
    {
        cout << "Complaint is in ACCOUNTS DEPARTMENT" << endl;
    }
    else {
        cout << "This Complaint Doesnot exist" << endl;
    }

}
// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};