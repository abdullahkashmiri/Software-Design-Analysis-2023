/**
 * Project Untitled
 */

#include "Employee.h"


 /**
  * Employee implementation
  */


Employee::Employee()
{
	id = -1;
	name = "";
	department = "";
	readAssignedJobsFromFile();
}

Employee::Employee(int id, string name, string dept)
{
	this->id = id;
	this->name = name;
	this->department = dept;
	readAssignedJobsFromFile();
}

void Employee::writeAssignedJobsToFile() {
    string filename = "assignedComplaints.txt";
    ofstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file for writing: " << filename << endl;
        return;
    }
    int a = -1;

    // Write each AssignedJob to the file
    for (const auto& assignedJob : assignedJobs) {
        file << assignedJob.getDate() << " "
            << assignedJob.getComplaintID() << " "
            << assignedJob.getTeacherID() << " " << a << " ";

        const vector<int>& employeeIDs = assignedJob.getEmployeeIDs();
        for (size_t i = 0; i < employeeIDs.size(); ++i) {
            file << employeeIDs[i];
            if (i < employeeIDs.size() - 1) {
                file << " ";
            }
        }

        file << " " << a << " " << stateToString(assignedJob.getStatus()) << "\n";
    }

    file.close();
}

void Employee::readAssignedJobsFromFile()
{
    string filename = "assignedComplaints.txt";
    ifstream file(filename);
    int cid;
    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    string line;
    while (getline(file, line)) {
        istringstream iss(line);
        istringstream iss1(line);
        AssignedJob assignedJob;

        // Assuming your AssignedJob class has a member function to read data from a string
        assignedJob.readAssignedJobFromString(line);
        
        assignedJobs.push_back(assignedJob);

        if (assignedJob.matchEmployeeId(iss1, id)) {
            cid = assignedJob.getComplaintID();
            complaintIDs.push_back(cid);
        }
    }

    file.close();
    return;
}

void Employee::printAssignedComplaints()
{
    cout << "--------------------------- PRINTING ASSIGNED COMPLAINTS ---------------------" << endl;
    for (const AssignedJob& assignedJob : assignedJobs) {
        // Assuming you have a function named "printDetails" in the AssignedJob class
        assignedJob.printAssignDetails(id);
        cout << "----------------------------------------------------------------------" << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;
    cout << "-------------------------++++++++++++++++++++++-----------------------------" << endl;
    pressAnyKeyToContinue();

}

void Employee::printAllAssignedComplaints()
{
    cout << "--------------------------- PRINTING ALL ASSIGNED COMPLAINTS ---------------------" << endl;
    for (const AssignedJob& assignedJob : assignedJobs) {
        // Assuming you have a function named "printDetails" in the AssignedJob class
        cout << assignedJob.printDetails(id) << endl;
        cout << "----------------------------------------------------------------------" << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;
    cout << "-------------------------++++++++++++++++++++++-----------------------------" << endl;
    pressAnyKeyToContinue();

}

string Employee::stateToString(State state)
{
    static const std::unordered_map<State, std::string> stateStrings = {
{State::New, "New"},
{State::Assigned, "Assigned"},
{State::Resolved, "Resolved"},
{State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
}

State Employee::stringToState(string str)
{
    static const std::unordered_map<std::string, State> stateMap = {
   {"New", State::New},
   {"Assigned", State::Assigned},
   {"Resolved", State::Resolved},
   {"Closed", State::Closed}
    };

    auto it = stateMap.find(str);
    if (it != stateMap.end()) {
        return it->second;
    }
    else {
        return State::New;  // Default value for unknown strings
    }
}

int Employee::getId() const {
	return id;
}

string Employee::getName()
{
	return name;
}

string Employee::getDepartment() const
{
	return department;
}

void Employee::setID(int ID)
{
	id = ID;
}

void Employee::setName(string Name)
{
	name = Name;
}

void Employee::setDepartment(string dept)
{
	department = dept;
}

void Employee::command() {
    int choice;
    do {
        system("cls");
        cout << " EMPLOYEE MAIN CONTROL PANEL \n"
            << "Name: "<<name<< " : "<<id<< " Department: "<<department<<" \n\n"
            << "1. Complete Assigned Job\n"
            << "2. Check All Assigned/Remaining Jobs\n"
            << "3. Show All Jobs [Assigned/Closed]\n"
            << "0. Exit\n"
            << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1: {
            updateSystem();
            break;
        }
        case 2:
            // 2. Check all assigned jobs
            printAssignedComplaints();
            break;
        case 3:
            // 3. Show all jobs
            printAllAssignedComplaints();
            break;
        case 0:
            // 0. Exit
            cout << "Exiting the command system." << endl;
            break;
        default:
            cout << "Invalid choice. Please enter a valid option." << endl;
        }
    } while (choice != 0);
}

void Employee::pressAnyKeyToContinue()
{
    cout << "Press any key to continue...";

#ifdef _WIN32
    _getch(); // Use _getch() on Windows
#else
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
#endif

    cout << endl;
}

void Employee::updateSystem() {
    cout << "----------------------------------------------------------------------" << endl;

    // Ask the user to enter the complaint ID they have resolved
    int resolvedComplaintID;
    cout << "Enter the complaint ID that you have resolved: ";
    cin >> resolvedComplaintID;
     

    // Check if the entered complaint ID is in the complaintIDs vector
    auto it = find(complaintIDs.begin(), complaintIDs.end(), resolvedComplaintID);

    if (it != complaintIDs.end()) {
        // The complaint ID is found, mark the corresponding complaint as resolved
        for (AssignedJob& assignedJob : assignedJobs) {
            if (assignedJob.getComplaintID() == resolvedComplaintID) {
                // Assuming "Resolved" is the status for resolved complaints
                assignedJob.setStatus(State::Resolved);
                writeAssignedJobsToFile();
                cout << "Complaint marked as resolved." << endl;
                pressAnyKeyToContinue();
                return;  // No need to continue searching
            }
        }
        cout << "Error: Corresponding assigned job not found for the complaint ID." << endl;
    }
    else {
        cout << "Error: Complaint ID not found in your list of assigned complaints." << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;
    pressAnyKeyToContinue();
}

string Employee::getName() const
{
	return name;
}

// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};
