/**
 * Project Untitled
 */

#include <iostream>
#include <string>
#include "Person.h"
#include "Department.h"
#include <conio.h>
#include <cstdlib>
#ifdef _WIN32
#include <conio.h>
#else
#include <iostream>
#include <limits>
#endif

using namespace std;

#ifndef _DIRECTOR_H
#define _DIRECTOR_H

class Director : virtual public Person {
private:
    int id;
    string name;
    Department* _adminDepartment;
    Department* _itDepartment;
    Department *_accountsDepartment;

public:

    Director();

    Director(int id, string name);

    int getId() const;
 
    string getName() const;

    void setID(int ID);

    void setName(string Name);

    void command();

    void pressAnyKeyToContinue();

    void Complains_in_Depts();

    void printAllComplaintsInTimeLine();

    void ComplainsSummary();

    void ComplainDetails();

    void ComplainDetails(int choice);
};

#endif //_DIRECTOR_H