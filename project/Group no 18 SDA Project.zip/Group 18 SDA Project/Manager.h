/**
 * Project Untitled
 */

#include <Windows.h>
#include <string>
#include <iostream>
#include <fstream>
#include <functional>
#include "Department.h"
#include "AssignedJob.h"
#include "Employee.h"
#include <sstream>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <vector>

#include <conio.h>
#include <cstdlib>
#ifdef _WIN32
#include <conio.h>
#else
#include <iostream>
#include <limits>
#endif


using namespace std;

#ifndef _MANAGER_H
#define _MANAGER_H

class Manager : virtual public Person {
private:
    int id;
    string name;
    string department;
    Department* _department;
    vector<AssignedJob> *assignedJobs;

public:
    Manager();

    Manager(int ID, string Name, string dept);

    void setID(int ID);

    void setName(string Name);

    void setdept(string dept);

    int notification();

    void PrintComplaints();

    void PrintAllEmployees();

    void PrintAssignedComplaints();
     
    void pressAnyKeyToContinue();

    int getId() const;

    string getName() const;
    
    string getDepartment() const;

    void writeAssignedJobsToFile();

    void readAssignedJobsFromFile();

    void command();

    void ReviewRequest();

    void AssignJob();

    void ReviewJob();

    void ApproveJob();

    void reviewFeedback();

    State stringToState(string str);

    string stateToString(State state);

   /* template<typename Temp>
    void LoadDataFromFileEmployee(string file, vector<Temp>& _vector);*/

};

#endif //_MANAGER_H
 