/**
 * Project Untitled
 */


#include "State.h"

 /**
  * State implementation
  */


void State::CurrentState() {

}

void State::ChangeState() {

}