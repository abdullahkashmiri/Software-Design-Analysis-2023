#include "Teacher.h"

 /**
  * Teacher implementation
  */



Teacher::Teacher()
{
	id = -1;
	name = "";
    _complaint = new vector<Complaint>();
}

Teacher::Teacher(int ID, string Name)
{
	this->id = ID;
	this->name = Name;
    _complaint = new vector<Complaint>();
}

int Teacher::getId() const
{
	return id;
}

string Teacher::getName() const
{
	return name;
}

void Teacher::setID(int ID)
{
    id = ID;
}

void Teacher::setName(string Name)
{
    name = Name;
}

int Teacher::notification()
{
    int count = 0;
    for (Complaint& complaint : *_complaint) {
        if (complaint.getComplaintTeacherId() == id && complaint.CurrentState() == State::Resolved && complaint.getFeedback() == -1) {
            count++;
        }
    }
    return count;
}

void Teacher::pressAnyKeyToContinue()
{
    cout << "Press any key to continue...";

#ifdef _WIN32
    _getch(); // Use _getch() on Windows
#else
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
#endif

    cout << endl;
}

void Teacher::command() {

    LoadAllComplaints();
    int choice = 1000;
    while (choice != 0) {
        system("cls");
        cout << "TEACHER MAIN CONTROL PANEL" << endl;
        cout << "Teacher " << name <<" ID: "<< id << endl << endl;
        cout << "-----------------------------------------------------------------------------------------" << endl;
        cout << "------------------- Notifications : " << notification() << " [Issues Resolved/Require FeedBack]  ---------------" << endl;
        cout << "-----------------------------------------------------------------------------------------" << endl;
        cout << "1. Make a complaint" << endl;
        cout << "2. Check status of a complaint" << endl;
        cout << "3. Record feedback" << endl;
        //cout << "4. Print all complaints" << endl;
        cout << "0. Exit" << endl;

        cout << "Enter your choice: ";
        cin >> choice;

        switch (choice) {
        case 1:
            MakeComplain();
            break;
        case 2:
            CheckComplaintStatus();
            break;
        case 3:
            RecordFeedback();
            break;
       // case 4:
          //  PrintComplains();
         //   break;
        case 0:
            cout << "Exiting Teacher Command Function." << endl;
            return;
        default:
            cout << "Invalid choice. Please enter a valid option." << endl;
        }
    }
}

void Teacher::CheckComplaintStatus() {
    int complaintId;

    cout << "Enter the complaint ID to check status: ";
    cin >> complaintId;
    // Find the complaint with the given ID
    for (const Complaint& complaint : *_complaint) {
        if (complaint.getId() == complaintId) {
            cout << "Complaint ID: " << complaint.getId() << ", Status: " << stateToString(complaint.CurrentState()) << endl;
            pressAnyKeyToContinue();
            return;
        }
    }

    cout << "Complaint with ID " << complaintId << " not found " << endl;
    pressAnyKeyToContinue();
}

void Teacher::MakeComplain() {
    // Ask user for complaint details
    cout << "Enter complaint query: ";
    string query;
    cin.ignore(); // Ignore the newline character from the previous input
    getline(cin, query);

    
    cout << "Enter department (1 for Admin, 2 for IT, 3 for Accounts): ";

    string department;
    getline(cin, department);

    // Validate the input
    while (department != "1" && department != "2" && department != "3") {
        cout << "Invalid department. Please enter 1, 2, or 3: ";
        getline(cin, department);
    }

    // Map numeric input to department names
    string departmentName;
    if (department == "1") {
        departmentName = "Admin";
    }
    else if (department == "2") {
        departmentName = "IT";
    }
    else {
        departmentName = "Accounts";
    }

    // Create a new complaint with the entered details
    // Assuming teacher_id is a member variable in the Teacher class
    Complaint newComplaint(_complaint->size() + 1, query, departmentName, id, State::New, -1);

    // Add the new complaint to the vector
    _complaint->push_back(newComplaint);

    // Save all complaints to the file after adding a new complaint
    SaveALLComplaints();
    cout << "Complaint ID is : "<<newComplaint.getId() << endl;
    cout << "Complaint added successfully!" << endl;
    pressAnyKeyToContinue();
}

// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};

void Teacher::PrintComplains() {
    for (const Complaint& complaint : *_complaint) {
        //complaint.PrintDetails(id);
        complaint.PrintDetails();
        cout << "-----------------------------------------------------------" << endl;
    }
    pressAnyKeyToContinue();
}

void Teacher::RecordFeedback() {
    // Check if there is any resolved complaint with the teacher's ID
    bool foundResolvedComplaint = false;

    for (Complaint& complaint : *_complaint) {
        if (complaint.getComplaintTeacherId() == id && complaint.CurrentState() == State::Resolved && complaint.getFeedback() == -1) {
            foundResolvedComplaint = true;
            break;
        }
    }

    if (!foundResolvedComplaint) {
        cout << "No resolved complaints found for Teacher " << name << "." << endl;
        pressAnyKeyToContinue();
        return;
    }

    for (Complaint& complaint : *_complaint) {
        if (complaint.getComplaintTeacherId() == id && complaint.CurrentState() == State::Resolved && complaint.getFeedback() == -1) {
            complaint.PrintDetails();
        }
    }
    int compID;
    cout << "Enter the ID of complaint you want to give feed back" << endl;
    cout << "Enter here ->> ";
    cin >> compID;

    bool forward = false;
    for (Complaint& complaint : *_complaint) {
        if (complaint.getComplaintTeacherId() == id && complaint.CurrentState() == State::Resolved && complaint.getId() == compID && complaint.getFeedback() == -1) {
            forward = true;
            break;
        }
    }

    if (forward) {

        int choice;
        bool satisfied = true;

        do {
            cout << "Please provide feedback for a resolved complaint:" << endl;
            cout << "1. Satisfied" << endl;
            cout << "2. Not Satisfied" << endl;
            cout << "0. Exit" << endl;
            cout << "Enter your choice: ";
            cin >> choice;

            switch (choice) {
            case 1:
                satisfied = true;
                break;
            case 2:
                satisfied = false;
                break;
            case 0:
                return; // Exit the function
            default:
                cout << "Invalid choice. Please enter 1, 2, or 0." << endl;
            }
        } while (choice != 1 && choice != 2);

        // Update the status based on user feedback
        for (Complaint& complaint : *_complaint) {
            if (complaint.getComplaintTeacherId() == id && complaint.CurrentState() == State::Resolved && complaint.getId() == compID) {
                // Assuming you have a method like setStatus in the Complaint class
                complaint.setFeedbackGiven(satisfied ? 1 : 0);
                SaveALLComplaints();
                cout << "Feedback recorded successfully!" << endl;
                pressAnyKeyToContinue();
                return;
            }
        }
    }
    cout << "Invalid complaint ID" << endl;
    pressAnyKeyToContinue();
}

void Teacher::LoadAllComplaints() {
    ifstream file("complaints.txt");
    if (file.is_open()) {
        int id, emp_id;
        string desc, dept, status;
        int teacher_id;
        string line;
        while (getline(file, line)) {
            stringstream iss(line);
            if (iss >> id >> dept >> teacher_id >> emp_id >> status) {
                getline(iss, desc);
                // Remove spaces before text
                desc.erase(desc.begin(), find_if(desc.begin(), desc.end(), [](char ch) {
                    return !isspace(ch);
                    }));
                // Assuming you have a constructor in Complaint class that takes these parameters
                Complaint newComplaint(id, desc, dept, teacher_id, stringToState(status), emp_id);

                // Add the loaded complaint to the vector
                _complaint->push_back(newComplaint);
            }
            else {
                cout << "Error parsing line: " << line << endl;
            }
        }
        file.close();
    }
    else {
        cout << "Unable to open file 'complaints.txt'" << endl;
    }
}

void Teacher::SaveALLComplaints() {
    ofstream file("complaints.txt");

    if (file.is_open()) {
        for (const Complaint& complaint : *_complaint) {
            file << complaint.getId() << " "
                << complaint.getComplaintDept() << " "
                << complaint.getComplaintTeacherId() << " "
                << complaint.getComplaintEmployeeId() << " "
                << stateToString(complaint.CurrentState()) << " "
            << complaint.getComplaintDesc() << endl;
        }

        file.close();
        cout << "Complaints saved successfully!" << endl;
    }
    else {
        cout << "Unable to open file 'complaints.txt' for writing." << endl;
    }
}

string Teacher::stateToString(State state)
{
    static const std::unordered_map<State, std::string> stateStrings = {
{State::New, "New"},
{State::Assigned, "Assigned"},
{State::Resolved, "Resolved"},
{State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
}

State Teacher::stringToState(string str)
{
    static const std::unordered_map<std::string, State> stateMap = {
    {"New", State::New},
    {"Assigned", State::Assigned},
    {"Resolved", State::Resolved},
    {"Closed", State::Closed}
    };

    auto it = stateMap.find(str);
    if (it != stateMap.end()) {
        return it->second;
    }
    else {
        return State::New;  // Default value for unknown strings
    }
}
