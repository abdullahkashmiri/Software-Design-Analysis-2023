/**
 * Project Untitled
 */


#include "Department.h"

 /**
  * Department implementation
  */

Department::Department()
{
	id = -1;
	name = "";
	_complaint = new vector<Complaint>();
	_employee = new vector<Employee>(); 
    assignedJob = new vector<AssignedJob>();
    LoadAllComplaints();
    LoadDataFromFileEmploye("employees.txt", _employee);
}

Department::Department(int ID, string Name)
{
	id = ID;
	name = Name;
	_complaint = new vector<Complaint>();
	_employee = new vector<Employee>();
    LoadAllComplaints();
    LoadDataFromFileEmploye("employees.txt", _employee);
}

int Department::getId()
{
	return id;
}

int Department::getId() const
{
    return id;
}

string Department::getName()
{
	return name;
}
// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};

string Department::getName() const
{
    return name;
}

int Department::getTotalComplaints()
{
	return totalComplains;
}

int Department::getTotalComplaints() const
{
    return totalComplains;
}

vector<Complaint>* Department::getData()
{
    return _complaint;
}
 
void Department::LoadDataFromFileEmploye(std::string file, std::vector<Employee>* _vector)
{
    std::ifstream inputFile(file);
    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open file: " << file << std::endl;
        return;
    }

    std::string line;
    while (std::getline(inputFile, line)) {
        std::stringstream ss(line);
        int id;
        std::string name, dept;

        if (ss >> id >> name >> dept) {
            Employee temp{ id, name, dept };
            _vector->push_back(temp);
        }
        else {
            std::cerr << "Error: Invalid data format in file: " << file << std::endl;
        }
    }

    inputFile.close();
}

void updateSpecificLine(const std::string& filePath, int lineToReplace, const std::string& newLine) {
    std::ifstream inputFile(filePath);
    if (!inputFile.is_open()) {
        std::cerr << "Error: Unable to open file: " << filePath << std::endl;
        return;
    }

    std::vector<std::string> lines;
    std::string line;
    while (std::getline(inputFile, line)) {
        lines.push_back(line);
    }

    inputFile.close();

    auto it = std::find_if(lines.begin(), lines.end(), [lineToReplace](const std::string& s) {
        std::istringstream iss(s);
        int firstInt;
        iss >> firstInt;
        return firstInt == lineToReplace;
        });

    if (it != lines.end()) {
        // Replace the line with the new line
        *it = newLine;

        // Write the updated content back to the file
        std::ofstream outputFile(filePath);
        for (const auto& updatedLine : lines) {
            outputFile << updatedLine << std::endl;
        }
        outputFile.close();

        std::cout << "Line updated successfully." << std::endl;
    }
    else {
        std::cerr << "Error: Line not found for update." << std::endl;
    }
}

void Department::LoadAllComplaints()
{
    ifstream file("complaints.txt");
    if (file.is_open()) {
        int id, emp_id;
        string desc, dept, status;
        int teacher_id;
        string line;
        while (getline(file, line)) {
            stringstream iss(line);
            if (iss >> id >> dept >> teacher_id >> emp_id >> status) {
                getline(iss, desc);
                // Remove spaces before text
                desc.erase(desc.begin(), find_if(desc.begin(), desc.end(), [](char ch) {
                    return !isspace(ch);
                    }));
                if (dept == name) {
                    totalComplains++;
                    // Assuming you have a constructor in Complaint class that takes these parameters
                    Complaint newComplaint(id, desc, dept, teacher_id, stringToState(status), emp_id);

                    // Add the loaded complaint to the vector
                    _complaint->push_back(newComplaint);
                }
            }
            else {
                cout << "Error parsing line: " << line << endl;
            }
        }
        file.close();
    }
    else {
        cout << "Unable to open file 'complaints.txt'" << endl;
    }
}

vector<Complaint>* Department::GetLoadedAllComplaints()
{

    vector<Complaint>* _tempComplaint = new vector<Complaint>();
    ifstream file("complaints.txt");
    if (file.is_open()) {
        int id, emp_id;
        string desc, dept, status;
        int teacher_id;
        string line;
        while (getline(file, line)) {
            stringstream iss(line);
            if (iss >> id >> dept >> teacher_id >> emp_id >> status) {
                getline(iss, desc);
                 
                // Remove spaces before text
                desc.erase(desc.begin(), find_if(desc.begin(), desc.end(), [](char ch) {
                    return !isspace(ch);
                    }));

                    totalComplains++;
                    // Assuming you have a constructor in Complaint class that takes these parameters
                    Complaint newComplaint(id, desc, dept, teacher_id, stringToState(status), emp_id);

                    // Add the loaded complaint to the vector
                    _tempComplaint->push_back(newComplaint);
                
            }
            else {
                cout << "Error parsing line: " << line << endl;
            }
        }
        file.close();
    }
    else {
        cout << "Unable to open file 'complaints.txt'" << endl;
    }
    return _tempComplaint;
}
 
void Department::writeComplaintsToFile(const std::string& filePath, int cid) {
    vector<Complaint>* _tempComplaint = GetLoadedAllComplaints();
    ofstream file("complaints.txt");

    if (file.is_open()) {
        for (const Complaint& complaint : *_tempComplaint) {
            if (complaint.getId() == cid) {
                file << complaint.getId() << " "
                    << complaint.getComplaintDept() << " "
                    << complaint.getComplaintTeacherId() << " "
                    << complaint.getFeedback() << " "
                    << "Assigned" << " "
                    << complaint.getComplaintDesc() << endl;
            }
            else {
                file << complaint.getId() << " "
                    << complaint.getComplaintDept() << " "
                    << complaint.getComplaintTeacherId() << " "
                    << complaint.getComplaintEmployeeId() << " "
                    << stateToString(complaint.CurrentState()) << " "
                    << complaint.getComplaintDesc() << endl;
            }
           

        }

        file.close();
        cout << "Complaints saved successfully!" << endl;
    }
    else {
        cout << "Unable to open file 'complaints.txt' for writing." << endl;
    }

}

void Department::writeComplaintsToFileResolved(const std::string& filePath, int cid) {
    vector<Complaint>* _tempComplaint = GetLoadedAllComplaints();
    ofstream file("complaints.txt");

    if (file.is_open()) {
        for (const Complaint& complaint : *_tempComplaint) {
            if (complaint.getId() == cid) {
                file << complaint.getId() << " "
                    << complaint.getComplaintDept() << " "
                    << complaint.getComplaintTeacherId() << " "
                    << complaint.getComplaintEmployeeId() << " "
                    << "Resolved" << " "
                    << complaint.getComplaintDesc() << endl;
            }
            else {
                file << complaint.getId() << " "
                    << complaint.getComplaintDept() << " "
                    << complaint.getComplaintTeacherId() << " "
                    << complaint.getComplaintEmployeeId() << " "
                    << stateToString(complaint.CurrentState()) << " "
                    << complaint.getComplaintDesc() << endl;
            }


        }

        file.close();
        cout << "Complaints saved successfully!" << endl;
    }
    else {
        cout << "Unable to open file 'complaints.txt' for writing." << endl;
    }

}

void Department::writeComplaintsToFileClosed(const std::string& filePath, int cid) {
    vector<Complaint>* _tempComplaint = GetLoadedAllComplaints();
    ofstream file("complaints.txt");

    if (file.is_open()) {
        for (const Complaint& complaint : *_tempComplaint) {
            if (complaint.getId() == cid) {
                file << complaint.getId() << " "
                    << complaint.getComplaintDept() << " "
                    << complaint.getComplaintTeacherId() << " "
                    << complaint.getComplaintEmployeeId() << " "
                    << "Closed" << " "
                    << complaint.getComplaintDesc() << endl;
            }
            else {
                file << complaint.getId() << " "
                    << complaint.getComplaintDept() << " "
                    << complaint.getComplaintTeacherId() << " "
                    << complaint.getComplaintEmployeeId() << " "
                    << stateToString(complaint.CurrentState()) << " "
                    << complaint.getComplaintDesc() << endl;
            }


        }

        file.close();
        cout << "Complaints saved successfully!" << endl;
    }
    else {
        cout << "Unable to open file 'complaints.txt' for writing." << endl;
    }

}

bool Department::isEmployeeIDValid(int employeeID) const
{
    // Use std::find to check if the employeeID exists in the vector
    auto it = find_if(_employee->begin(), _employee->end(),
        [employeeID](const Employee& emp) {
            return (emp.getId() == employeeID);
        });

    // Return true if the employeeID is found, otherwise false
    return it != _employee->end();
}

string Department::EmployeeIDdept(int employeeID) const
{
    auto it = std::find_if(_employee->begin(), _employee->end(),
        [employeeID](const Employee& emp) {
            return (emp.getId() == employeeID);
        });

    // Check if the employeeID is found
    if (it != _employee->end()) {
        // Return the department of the found employee
        return it->getDepartment();
    }
    else {
        // Return an empty string or some indication that the employeeID wasn't found
        return "";
    }
}

void Department::printAllEmployees(string dept)
{
    // Iterate through the vector of employees
    for (const auto& employee : *_employee) {
        if (employee.getDepartment() == dept) {
            cout << "ID: " << employee.getId() << ", Name: " << employee.getName()
                << ", Department: " << employee.getDepartment() << endl;
        }
    }
}

bool Department::isComplaintIDValid(int complaintID) const
{
    // Use std::find to check if the complaintID exists in the vector
    auto it = find_if(_complaint->begin(), _complaint->end(),
        [complaintID](const Complaint& complaint) {
            return complaint.getId() == complaintID;
        });

    // Return true if the complaintID is found, otherwise false
    return it != _complaint->end();
}
 
string Department::getFormattedLine(int id)
{
    int complaintID = id;
    auto it = std::find_if(_complaint->begin(), _complaint->end(), [complaintID](const Complaint& complaint) {
        return complaint.getId() == complaintID;
        });

    if (it != _complaint->end()) {
        // Update the complaint status
        it->setCurrentState(State::Assigned);  // Assuming you have a method to set the current state of the complaint

        // Return the formatted string
        return to_string(it->getId()) + " " + it->getComplaintDept() + " " +
            to_string(it->getComplaintTeacherId()) + " -1 " + stateToString(it->CurrentState()) + " " + it->getComplaintDesc();
    }
    else {
        return "Complaint not found";
    }
}

void Department::setFeedback(int cid)
{
    for (Complaint& complaint : *_complaint) {
        if (complaint.getId() == cid) {
            complaint.setFeedbackGiven(-1);
        }
    }
}

bool Department::isFeedbackGivenByComplaintId(int c)
{
    for ( Complaint& complaint : *_complaint) {
        if (complaint.getId() == c) {
            if (complaint.getFeedback() != -1) {
                return true;
            }
        }
    }
    return false;
}
// Update complaint status by ID
void Department::updateComplaintStatus(int complaintID, const State& newStatus) {
    auto it = find_if(_complaint->begin(), _complaint->end(),
        [complaintID](const Complaint& complaint) {
            return complaint.getId() == complaintID;
        });

    if (it != _complaint->end()) {
        it->setCurrentState(newStatus);
    }
    else {
        throw runtime_error("Complaint ID not found.");
    }
}

State Department::getComplaintStatusByID(int complaintID) const {
    auto it = find_if(_complaint->begin(), _complaint->end(),
        [complaintID](const Complaint& complaint) {
            return complaint.getId() == complaintID;
        });

    if (it != _complaint->end()) {
        return it->CurrentState();
    }
    else {
        throw runtime_error("Complaint ID not found.");
    }
}

int Department::getComplaintTeacherIdByID(int complaintID) const {
    auto it = find_if(_complaint->begin(), _complaint->end(),
        [complaintID](const Complaint& complaint) {
            return complaint.getId() == complaintID;
        });

    if (it != _complaint->end()) {
        return it->getComplaintTeacherId();
    }
    else {
        throw runtime_error("Complaint ID not found.");
    }
}

void Department::printAllComplaints() const {
    cout << "-------------------------------------------------------" << endl;
    cout << "           All Complaints in Department : " << name << "      \n";
    cout << "-------------------------------------------------------" << endl;
    for (const auto& complaint : *_complaint) {
        complaint.PrintDetails();
    }
    cout << "-------------------------------------------------------" << endl;
    cout << "--------------------++++++++++++++++-------------------" << endl;
    cout << "-------------------------------------------------------" << endl;

}

void Department::printNewComplaints() const {
   
    cout << "-------------------------------------------------------" << endl;
    cout << "           NEW Complaints in Department : " << name << "      \n";
    cout << "-------------------------------------------------------" << endl;

    for (const auto& complaint : *_complaint) {
        if (complaint.CurrentState() == State::New) {
            cout << "Complaint ID: " << complaint.getId() << " "
                << "Description: " << complaint.getComplaintDesc() << " "
                << "Teacher ID: " << complaint.getComplaintTeacherId() << " "
                << "Employee ID: " << complaint.getComplaintEmployeeId() << " "
                << "Status: " << stateToString(complaint.CurrentState()) << "\n";
        }
    }

    cout << "-------------------------------------------------------" << endl;
    cout << "--------------------++++++++++++++++-------------------" << endl;
    cout << "-------------------------------------------------------" << endl;
}

void Department::UpdateComplaintStatusAfterFeedback()
{
    for (auto& complaint : *_complaint) {
        if (complaint.CurrentState() == State::Resolved) {
            int feedback = complaint.getFeedback();
            cout << "Teacher : " << complaint.getComplaintTeacherId() << " for complainty ID: " << complaint.getId() << endl;
            if (feedback == -1) {
                cout << "Has not yet given feedback " << endl;
            }
            else if (feedback == 0) {
                cout << "feedback is Disatisfied So opening this issue again!!" << endl;
                complaint.ChangeState(State::New);
                writeComplaintsToFile("complaints.txt", complaint.getId());
            }
            else if (feedback == 1) {
                cout << "feedback is Satisfied So closing this issue!!" << endl;
                complaint.ChangeState(State::Closed);
                writeComplaintsToFileClosed("complaints.txt", complaint.getId());
            }
            else {
                cout << "Some error occurred in giving feedback. Looking into it." << endl;
            }
        }
    }
}

vector<int> Department::printAccoringToMonth(int smon, int sye, int sda, int emon, int eye, int eda) {
    readAssignedJobsFromFile();
    vector<int> jobs;

    for (AssignedJob& job : *assignedJob) {
        string date = job.getDate();
        istringstream iss(date);
        string token;

        // Extract month
        getline(iss, token, '/');
        int month = stoi(token);

        // Extract day
        getline(iss, token, '/');
        int day = stoi(token);

        // Extract year
        getline(iss, token);
        int year = stoi(token);

        if (year >= sye && year <= eye) {
            if (month >= smon && month <= emon) {
                if (day >= sda && day <= eda) {
                    int newComplaintID = job.getComplaintID();
                    auto it = find(jobs.begin(), jobs.end(), newComplaintID);
                    if (it == jobs.end()) {
                        // newComplaintID is not in 'jobs', so add it
                        jobs.push_back(newComplaintID);
                    }
                }
            }
        }
      
    }
    return jobs;
}

State Department::stringToState(string str)
{
    static const std::unordered_map<std::string, State> stateMap = {
    {"New", State::New},
    {"Assigned", State::Assigned},
    {"Resolved", State::Resolved},
    {"Closed", State::Closed}
    };

    auto it = stateMap.find(str);
    if (it != stateMap.end()) {
        return it->second;
    }
    else {
        return State::New;  // Default value for unknown strings
    }
}

string Department::stateToString(State state) const
{
    static const std::unordered_map<State, std::string> stateStrings = {
   {State::New, "New"},
   {State::Assigned, "Assigned"},
   {State::Resolved, "Resolved"},
   {State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
}

string Department::stateToString(State state)
{

    static const std::unordered_map<State, std::string> stateStrings = {
   {State::New, "New"},
   {State::Assigned, "Assigned"},
   {State::Resolved, "Resolved"},
   {State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
} 

const Complaint& Department::getComplaintByID(int complaintID) const {
    auto it = find_if(_complaint->begin(), _complaint->end(),
        [complaintID](const Complaint& complaint) {
            return complaint.getId() == complaintID;
        });

    if (it != _complaint->end()) {
        return *it;
    }
    else {
        throw runtime_error("Complaint ID not found.");
    }
}

bool Department::printComplaintByID(int complaintID) {
    for (Complaint& complaint : *_complaint) {
        if (complaint.getId() == complaintID) {
            complaint.PrintDetail();
                return true;
        }
    }
    return false;
}

void Department:: readAssignedJobsFromFile()
{
    string filename = "assignedComplaints.txt";
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    delete assignedJob; // Clear the existing data in assignedJobs vector
    assignedJob = new vector<AssignedJob>();

    string line;
    while (getline(file, line)) {
        AssignedJob job;
        job.readAssignedJobFromString(line);
        assignedJob->push_back(job);
    }

    file.close();
}