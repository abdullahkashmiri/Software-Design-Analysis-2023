/**
 * Project Untitled
 */

#include "Person.h"
#include <iostream>
#include <Windows.h>
#include <string>
#include <iostream>
#include <fstream>
#include "AssignedJob.h"
#include <sstream>
#include <vector>
#include <conio.h>
#include <cstdlib>
#ifdef _WIN32
#include <conio.h>
#else
#include <iostream>
#include <limits>
#endif

using namespace std;

#ifndef _EMPLOYEE_H
#define _EMPLOYEE_H

class Employee: virtual public Person{
private:
    int id;
    string name;
    string department;
    vector<AssignedJob> assignedJobs;
    vector<int> complaintIDs;

public:

    Employee();

    Employee(int ID, string Name, string dept);
    
    int getId() const;

    string getName();

    string getDepartment() const;

    void setID(int ID);

    void setName(string Name);

    void setDepartment(string dept);

    void command();

    void pressAnyKeyToContinue();

    void updateSystem();

    string getName() const;

    void writeAssignedJobsToFile();

    void readAssignedJobsFromFile();

    void printAssignedComplaints();

    void printAllAssignedComplaints();

    string stateToString(State state);

    State stringToState(string str);

};

#endif //_EMPLOYEE_H