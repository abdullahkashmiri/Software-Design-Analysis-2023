/**
 * Project Untitled
 */

#include <string>
#include <iostream>
#include <sstream>
#include <fstream>
#include <vector>

#include "State.h"

using namespace std;

#ifndef _ASSIGNED JOB_H
#define _ASSIGNED JOB_H

class AssignedJob {
    string assignDate;
    int complaintID;
    int teacherID;
    vector<int> employeeIDs;
    State status;
public:
    AssignedJob();

    AssignedJob(string date, int cid, int tid, vector<int> e_ids, State status);

    void setComplaintID(int id);

    int getComplaintID() const;

    void setTeacherID(int id);

    int getTeacherID() const;

    void setEmployeeIDs(const vector<int>& ids);

    const vector<int>& getEmployeeIDs() const;

    void setDate(string d);
    string getDate() const;

    void setStatus(State s);

    State getStatus() const;

    // Read from string stream
    void readAssignedJobFromString(string line);

    bool matchEmployeeId(istringstream& iss, int eid);

    // Write to file
    void writeAssignedJobToFile(ofstream& file) const;

    string printDetails(int eid) const;

    string printDetails() const;

    void printAssignDetails(int eid) const;

    void printAssignDetails() const;

    void printResolvedDetails() const;

    bool printResolvedDetails() ;

    string stateToString(State status) const;

    State stringToState(string state);

};
 

#endif //_ASSIGNEDJOB_H