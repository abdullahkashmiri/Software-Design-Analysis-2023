/**
 * Project Untitled
 */


#include "Manager.h"

 /**
  * Manager implementation
  */


Manager::Manager()
{
    id = -1;
    name = "";
    department = "";
    _department = new Department();
    assignedJobs = new vector<AssignedJob>();
    readAssignedJobsFromFile();
}

Manager::Manager(int ID, string Name, string dept)
{
    this->id = ID;
    this->name = Name;
    department = dept;

    assignedJobs = new vector<AssignedJob>();
    if(dept == "Admin") 
        _department = new Department(1, "Admin");
    else if(dept == "IT")
        _department = new Department(2, "IT");
    else if (dept == "Accounts")
        _department = new Department(3, "Accounts");
    readAssignedJobsFromFile();
}

void Manager::setID(int ID)
{
    id = ID;
}

void Manager::setName(string Name)
{
    name = Name;
}

void Manager::setdept(string dept)
{
    department = dept;
}

int Manager::notification()
{
    int count = 0;
    int comID = 0;
    for (AssignedJob& assignedJob : *assignedJobs) {
        if (assignedJob.getStatus() == State::Resolved) {
            comID = assignedJob.getComplaintID();
            if (_department->getComplaintStatusByID(comID) == State::Assigned) {
                count++;
            }
        }
    }
    return count;
}

void Manager::PrintComplaints()
{
    _department->printAllComplaints();
    pressAnyKeyToContinue();
}

void Manager::PrintAllEmployees()
{
    _department->printAllEmployees(department);
    pressAnyKeyToContinue();
}

void Manager::PrintAssignedComplaints()
{
    cout << "-------------------- Printing All Assigned Complaints ----------------" << endl;
    for (AssignedJob& assignedJob : *assignedJobs) {

        assignedJob.printAssignDetails();
        cout << "--------------------------------------------------------------" << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;

    pressAnyKeyToContinue();
}

void Manager::pressAnyKeyToContinue()
{
    cout << "Press any key to continue...";

#ifdef _WIN32
    _getch(); // Use _getch() on Windows
#else
    cin.clear();
    cin.ignore(numeric_limits<streamsize>::max(), '\n');
#endif

    cout << endl;
}
 
int Manager::getId() const
{
    return id;
}

string Manager::getName() const
{
    return name;
}

string Manager::getDepartment() const
{
    return department;
}

void Manager::writeAssignedJobsToFile() {
    string filename = "assignedComplaints.txt";
    ofstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file for writing: " << filename << endl;
        return;
    }
    int a = -1;

    // Write each AssignedJob to the file
    for (const auto& assignedJob : *assignedJobs) {
        file << assignedJob.getDate() << " "
            << assignedJob.getComplaintID() << " "
            << assignedJob.getTeacherID() << " " << a << " ";

        const vector<int>& employeeIDs = assignedJob.getEmployeeIDs();
        for (size_t i = 0; i < employeeIDs.size(); ++i) {
            file << employeeIDs[i];
            if (i < employeeIDs.size() - 1) {
                file << " ";
            }
        }
        file << " " << a << " " << stateToString(assignedJob.getStatus()) << "\n";
    }

    file.close();
}

void Manager::readAssignedJobsFromFile()
{
    string filename = "assignedComplaints.txt";
    ifstream file(filename);

    if (!file.is_open()) {
        cerr << "Error opening file: " << filename << endl;
        return;
    }

    delete assignedJobs; // Clear the existing data in assignedJobs vector
    assignedJobs = new vector<AssignedJob>();

    string line;
    while (getline(file, line)) {
        AssignedJob job;
        job.readAssignedJobFromString(line);
        assignedJobs->push_back(job);
    }

    file.close();
}

std::string getCurrentDate() {
    // Get the current time
    time_t currentTime = time(nullptr);
    struct tm localTimeInfo;

    // Use localtime_s to ensure safe usage
    if (localtime_s(&localTimeInfo, &currentTime) != 0) {
        // Handle error
        return "Error occurred while getting time";
    }

    char formattedTime[20];  // Assuming the format "12/12/2022", so 20 characters are enough

    if (strftime(formattedTime, sizeof(formattedTime), "%m/%d/%Y", &localTimeInfo) == 0) {
        // Handle error
        return "Error occurred while formatting time";
    }

    // Convert the formatted time to a string and return it
    return std::string(formattedTime);
}

void Manager::command()
{
    cout << "Command Function" << endl;
    int option;
    do {
        system("cls");
        cout << "MANAGER MAIN CONTROL PANEL" << endl;
        cout << "Name: " << name << "  ID: " << id << " Department: " << department << " \n" << endl;
        cout << "-----------------------------------------------------------------------------------------" << endl;
        cout << "---------------  Notifications : " << notification() << " [Issues Resolved/Need Approval]  ---------------------" << endl;
        cout << "-----------------------------------------------------------------------------------------" << endl;
        cout << "1. Review Request & Approve (Forwarded/Notified to Teacher)" << endl;
        cout << "2. Assign Job" << endl;
        cout << "3. Review Job / Check current Status of Jobs" << endl;
        cout << "4. Display Complaints" << endl;
        cout << "5. Display Assigned Complaints" << endl;
        cout << "6. Check Feedback Status For Complaints" << endl;
        cout << "7. Display All Employees" << endl;
        cout << "0. Exit" << endl;
        cout << "Enter your choice: ";
        cin >> option;

        switch (option) {
        case 1:
            ReviewRequest();// Review Request & Approve (Forwarded/Notified to Teacher)
            break;
        case 2:
            AssignJob(); // assign a job to an employee
            break;
        case 3:
            ReviewJob();//Review Job / Check current Status of Jobs
            break;
        case 4:
            PrintComplaints(); // all complaints
            break;
        case 5:
            PrintAssignedComplaints(); // only assigned complaints
            break;
        case 6:
            reviewFeedback(); // review teacher feedback
            break;
        case 7:
            PrintAllEmployees(); // all employees of dept
            break;
        case 0:
            cout << "Exiting Manager Menu." << endl;
            break;
        default:
            cout << "Invalid choice. Please enter a valid option." << endl;
        }

    } while (option != 0);
}
    
void Manager::ReviewRequest() {
    bool found = false;
    cout << "-------------------- ALL COMPLAINTS [DONE/RESOLVED] BY Employees ----------------" << endl;
    for (AssignedJob& assignedJob : *assignedJobs) {
        if (assignedJob.printResolvedDetails())
        {
            found = true;
            cout << endl;
        }
    }
    if (found) {
        cout << "\nDo you want to Forward/Approve this to Teacher\nEnter Y | y else any other Key" << endl;
        char ch;
        cin >> ch;
        if (ch == 'y' || ch == 'Y') {
            ApproveJob();
        }

        else {
            cout << "Incorrect Entry!" << endl;
        }
    }
    else {
        cout << "No Assigned Complaints found." << endl;
    }
    cout << "----------------------------------------------------------------------" << endl;
    pressAnyKeyToContinue();
}

void Manager::AssignJob() {
    // Display new complaints from the department
    _department->printNewComplaints();

    // Ask for Complaint ID
    int complaintID;
    cout << "Enter the Complaint ID you want to assign employees to: ";
    cin >> complaintID;

    // Check if the entered Complaint ID is valid and has status "New"
    if (_department->isComplaintIDValid(complaintID)) {
        State complaintStatus = _department->getComplaintStatusByID(complaintID);

        // Check if the selected complaint has status "New"
        if (complaintStatus == State::New) {
            // Ask how many employees to assign
            int numEmployees;
            cout << "Enter the number of employees you want to assign: ";
            cin >> numEmployees;

            // Get employee IDs
            vector<int> employeeIDs;
            for (int i = 0; i < numEmployees; ++i) {
                int employeeID;

                // Check if the entered employee ID exists in the Department
                while (true) {
                    cout << "Enter Employee ID " << i + 1 << ": ";
                    cin >> employeeID;

                    // Assuming Department class has a function to check if an employee ID exists
                    if (_department->isEmployeeIDValid(employeeID)) {
                        if (_department->EmployeeIDdept(employeeID) == department) {
                            break;
                        }
                        else {
                            cout << "Employee is not in "<<department<<" department\nPlease enter a valid ID from your department or check All employees in control panel.\n";
                        }
                    }
                    else {
                        cout << "Invalid Employee ID.\nPlease enter a valid ID.\n";
                    }
                }

                employeeIDs.push_back(employeeID);
            }

            // Assign the job and update the status
            AssignedJob newAssignedJob;
            newAssignedJob.setComplaintID(complaintID);
            newAssignedJob.setTeacherID(_department->getComplaintByID(complaintID).getComplaintTeacherId());
            newAssignedJob.setEmployeeIDs(employeeIDs);
            newAssignedJob.setDate(getCurrentDate()); // You need to implement this function
            newAssignedJob.setStatus(State::Assigned);
            assignedJobs->push_back(newAssignedJob);

            cout << "Job assigned successfully!\n";

            // Update the complaint status to "Assigned" in the department
            _department->updateComplaintStatus(complaintID, State::Assigned);
            _department->setFeedback(complaintID);

           // _department->updateSpecificLine("complaints.txt", complaintID, _department->getFormattedLine(complaintID));

            _department->writeComplaintsToFile("complaints.txt", complaintID);
            // Call the function to write all data back to the file
            writeAssignedJobsToFile();
           

        }
        else {
            cout << "Selected complaint is not in 'New' or feedback not avaliable. Cannot assign employees.\n";
        }
    }
    else {
        cout << "Invalid Complaint ID. Please enter a valid ID.\n";
    }
    pressAnyKeyToContinue();
}

void Manager::ReviewJob() {
     readAssignedJobsFromFile();
    // Ask the user to enter a complaint ID
    int complaintID;
    cout << "Enter the Complaint ID you want to review: ";
    cin >> complaintID;

    // Check if the entered complaint ID is valid
    if (_department->isComplaintIDValid(complaintID)) {
        // Display the status of the complaint from the AssignedJob vector
        auto it = find_if(assignedJobs->begin(), assignedJobs->end(),
            [complaintID](const AssignedJob& assignedJob) {
                return assignedJob.getComplaintID() == complaintID;
            });

        if (it != assignedJobs->end()) {
            cout << "Complaint ID: " << it->getComplaintID() << "\n"
                << "Status: " << stateToString(it->getStatus()) << "\n";
        }
        else {
            cout << "Status not found for Complaint ID: " << complaintID << "\n";
        }
    }
    else {
        cout << "Incorrect entry or Complaint ID not found.\n";
    }
    pressAnyKeyToContinue();
}

void Manager::ApproveJob()
{
    readAssignedJobsFromFile();
    // Ask for Complaint ID
    int complaintID;
    cout << "Enter the Resolved Complaint ID you want to forward to Teacher: ";
    cin >> complaintID;

    // Check if the entered Complaint ID is valid and has status "New"
    if (_department->isComplaintIDValid(complaintID)) {
        State complaintStatus = _department->getComplaintStatusByID(complaintID);
        State assignedStatus = State::Resolved;
        bool found = false;
        AssignedJob foundJob;
        for (AssignedJob& assignedJob : *assignedJobs) {
            if (assignedJob.getComplaintID() == complaintID && assignedJob.getStatus() == assignedStatus) {
                found = true;
                 break;
           }
        }

        if (found) {
            // Check if the selected complaint has status "New"
            if (complaintStatus == State::Assigned) {
                cout << "Job Forwarded successfully!\n";
                // Update the complaint status to "Assigned" in the department
                _department->updateComplaintStatus(complaintID, State::Resolved);
                _department->writeComplaintsToFileResolved("complaints.txt", complaintID);
                // Call the function to write all data back to the file
             
            }
            else {
                cout << "Selected complaint is not in 'Assigned' status. Cannot Resolved Again.\n";
            }
        }
        else {
            cout << "Complaint has not been resolved yet." << endl;
        }
    }
    else {
        cout << "Invalid Complaint ID. Please enter a valid ID.\n";
    }
    pressAnyKeyToContinue();
}

void Manager::reviewFeedback()
{
    cout << "Do you want System to Check Feedback Status [Caution! Its an Automated Process]" << endl;
    cout << "Press Y | y to continue" << endl;
    char ch;
    cin >> ch;
    if (ch == 'Y' || ch == 'y') {

        _department->UpdateComplaintStatusAfterFeedback();
        int comID = 0;
        bool doUpdate = false;
        for (AssignedJob& assignedJob : *assignedJobs) {
            if (assignedJob.getStatus() == State::Resolved) {
                comID = assignedJob.getComplaintID();
                if (_department->isFeedbackGivenByComplaintId(comID)) {
                    assignedJob.setStatus(State::Closed);
                    doUpdate = true;
                    cout << "Complaint ID Closed: " << comID << endl;
                }
            }
        }
        if (doUpdate)
            writeAssignedJobsToFile();
        else {
            cout << "Incorrect Entry!" << endl;
        }
        pressAnyKeyToContinue();
    }

}

State Manager::stringToState(string str)
{
    static const std::unordered_map<std::string, State> stateMap = {
    {"New", State::New},
    {"Assigned", State::Assigned},
    {"Resolved", State::Resolved},
    {"Closed", State::Closed}
    };

    auto it = stateMap.find(str);
    if (it != stateMap.end()) {
        return it->second;
    }
    else {
        return State::New;  // Default value for unknown strings
    }
}

// Declare an unordered_map to map State enum values to strings
const unordered_map<State, string> stateStrings = {
    {State::New, "New"},
    {State::Assigned, "Assigned"},
    {State::Resolved, "Resolved"},
    {State::Closed, "Closed"}
};

string Manager::stateToString(State state)
{
    static const std::unordered_map<State, std::string> stateStrings = {
{State::New, "New"},
{State::Assigned, "Assigned"},
{State::Resolved, "Resolved"},
{State::Closed, "Closed"}
    };

    auto it = stateStrings.find(state);
    if (it != stateStrings.end()) {
        return it->second;
    }
    else {
        return "Unknown";
    }
}
